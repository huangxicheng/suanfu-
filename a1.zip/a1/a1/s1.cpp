#include "stdafx.h"
#include "s1.h" 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int init(sqstack &s)
{
	s.base = (char *)malloc(M * sizeof(char));
	if (!s.base)
	{
		exit(-1);
	}
	s.top = 0;
	s.stacksize = M;
	return 1;

}

int push(sqstack &s, char e)
{
	char *newbase;
	if (s.top == s.stacksize)
	{
		newbase = (char *)realloc(s.base, (s.stacksize + add) * sizeof(char));
		if (!newbase)
		{
			exit(-1);
		}
		s.base = newbase;
		s.stacksize += add;
	}
	s.base[s.top++] = e;
	return 1;
}

int pop(sqstack &s, char &e)
{
	if (!s.top)
	{
		exit(-1);
	}
	e = s.base[--s.top];
	return 1;
}

int Gettop(sqstack s, char &e)
{
	if (!s.top)
	{
		exit(-1);
	}
	e = s.base[s.top - 1];
	return 1;
}

int init_data(datastack &s)
{
	s.base = (float *)malloc(M * sizeof(float));
	if (!s.base)
	{
		exit(-1);
	}
	s.top = 0;
	s.stacksize = M;
	return 1;
}

int push_data(datastack &s, float e)
{
	float *newbase;
	if (s.top == s.stacksize)
	{
		newbase = (float *)realloc(s.base, (s.stacksize + add) * sizeof(float));
		if (!newbase)
		{
			exit(-1);
		}
		s.base = newbase;
		s.stacksize += add;

	}
	s.base[s.top++] = e;
	return 1;

}

int pop_data(datastack &s, float &e)
{
	if (!s.top)
	{
		exit(-1);
	}
	e = s.base[--s.top];
	return 1;
}

int gettop_data(datastack s, float &e)
{
	if (!s.top)
	{
		exit(-1);
	}
	e = s.base[s.top - 1];
	return 1;
}


char judge(char a, char b)
{
	switch (a)
	{
	case '+':
		if (b == '+' || b == '-' || b == ')' || b == '#')
		{
			return '>';
		}
		else
		{
			return '<';
		}
	case '-':
		if (b == '+' || b == '-' || b == ')' || b == '#')
		{
			return '>';
		}
		else
		{
			return '<';
		}
	case '*':
		if (b == '(' || b == '^')
		{
			return '<';
		}
		else
		{
			return '>';
		}
	case '/':
		if (b == '(' || b == '^')
		{
			return '<';
		}
		else
		{
			return '>';
		}
	case '#':
		if (b == '#')
		{
			return '=';
		}
		else if (b == ')')
		{
			return ' ';
		}
		else
		{
			return '<';
		}
	case '(':
		if (b == ')')
		{
			return '=';
		}
		else if (b == '#')
		{
			return ' ';
		}
		else
		{
			return '<';
		}
	case ')':
		if (b == '(')
		{
			return ' ';
		}
		else
		{
			return '>';
		}
	case '^':
		if (b == '(')
		{
			return '<';
		}
		else
		{
			return '>';
		}
	default:
		return ' ';

	}
}

float action(float a, char k, float b)
{
	switch (k)
	{
	case '+':
		return a + b;
	case '-':
		return a - b;
	case '*':
		return a * b;
	case '/':
		return a / b;
	case '^':
		return pow(a, b);
	default:
		return 0.0;
	}
}
int isysf(char c)
{
	if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')' || c == '#' || c == '^')
	{
		return 1;
	}
	return 0;
}


float hehe(char *input)
{
	sqstack optr;
	datastack opnd;
	float a, b, data, ku = 0;
	int i = 0;
	float ans;
	int flag = 0; /*�����ж��Ƿ�Ϊ����*/
	char e, x, y;
	char tempdata[20], ap[2] = { '#', '\0' };
	char *c;
	init(optr);
	init_data(opnd);
	push(optr, '#');
	c = strcat(input, ap);
	strcpy(tempdata, "\0");
	Gettop(optr, e);
	while (c[i] != '#' || e != '#')
	{
		if (!isysf(c[i]))
		{
			ap[0] = c[i];
			strcat(tempdata, ap);
			i++;
			if (isysf(c[i]))
			{
				data = atof(tempdata);
				push_data(opnd, data);
				strcpy(tempdata, "\0");
			}
			flag = 0;
		}
		else
		{
			if (flag) /*�������������������*/
			{
				Gettop(optr, y);
				if (y == '(' && c[i] == '-') /*�ж������Ƿ�Ϊ����*/
				{
					push_data(opnd, ku);  /*0�������ջ*/
					push(optr, c[i]);
					i++;
				}
				else /*�����������������ȴ���Ǹ���*/
				{
					switch (judge(e, c[i]))
					{
					case '<':
						push(optr, c[i]);
						i++;
						break;
					case '=':
						pop(optr, x);
						i++;
						break;
					case '>':
						pop(optr, e);
						pop_data(opnd, a);
						pop_data(opnd, b);
						push_data(opnd, action(b, e, a));
						break;
					}
				}

			}
			else
			{
				switch (judge(e, c[i]))
				{
				case '<':
					push(optr, c[i]);
					i++;
					break;
				case '=':
					pop(optr, x);
					i++;
					break;
				case '>':
					pop(optr, e);
					pop_data(opnd, a);
					pop_data(opnd, b);
					push_data(opnd, action(b, e, a));
					break;
				}
			}
			flag = 1;
		}
		Gettop(optr, e);
	}
	gettop_data(opnd, ans);
	return ans;

}
