#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define M 10
#define add 10
typedef struct
{
	char *base;
	int stacksize;
	int top;
} sqstack;

int init(sqstack &s);
int push(sqstack &s, char e);
int pop(sqstack &s, char &e);
int Gettop(sqstack s, char &e);
typedef struct
{
	float *base;
	int top;
	int stacksize;
} datastack;
int init_data(datastack &s);
int push_data(datastack &s, float e);
int pop_data(datastack &s, float &e);
int gettop_data(datastack s, float &e);
char judge(char a, char b);
float action(float a, char k, float b);
int isysf(char c);
float hehe(char *input);
